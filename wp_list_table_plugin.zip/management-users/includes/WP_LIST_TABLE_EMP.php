<?php
if (!class_exists('WP_List_Table')) {
    require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

class VIP_Users_List_Table extends WP_List_Table
{

// تنظیمات اولیه (تعداد آیتم‌ها در هر صفحه)
    function __construct()
    {
        parent::__construct([
            'singular' => 'کاربر VIP', // برای یک مورد
            'plural' => 'کاربران VIP', // برای چند مورد
            'ajax' => false // آیا از AJAX استفاده شود یا خیر
        ]);
    }

// bulk actions
    public function get_bulk_actions()
    {

        return [
            'delete'    => 'خذف',
            'send_msg'  => 'ارسال پیام'
        ];
    }

// ستون‌های جدول
    function get_columns()
    {
        return [
            'cb' => '<input type="checkbox" />', // چک باکس برای انتخاب چندگانه
            'ID' => ' شناسه',
            'full_name' => 'نام کامل',
            'birthday' => 'تاریخ تولد',
            'email' => 'ایمیل',
            'img' => 'تصویر',
            'created_at' => 'تاریخ ثبت نام'
        ];
    }

// داده‌ها برای هر ستون
    function column_default($item, $column_name)
    {
        return $item[$column_name];
    }

    public function column_full_name($item)
    {
        $delete_link = admin_url('admin.php?page=vip-users-list&action=delete&id=' . $item['ID']);
        $edit_link = admin_url('admin.php?page=vip-users-list&action=edit&id=' . $item['ID']);
        $actions = array(
            'edit' => "<a target='_blank' href='$edit_link'>ویرایش</a>",
            'delete' => "<a href='$delete_link'>حذف</a>"
        );
        return $item['full_name'] . $this->row_actions($actions);
    }

    public function column_img($item)
    {
        if ($item['img']) {
            return '<img width="30" src="' . $item['img'] . '" />';
        }
    }

    public function column_cb($item)
    {
        return "<input type=\"checkbox\"  name='pro_user_select[]' value='$item[ID]' />";
    }

// تنظیمات قابل مرتب‌سازی
    function get_sortable_columns()
    {
        return [
            'full_name' => ['full_name', 'desc'],
        ];
    }

// آماده‌سازی داده‌ها
    function prepare_items()
    {
        $this->proccess_data_in_bulk_actions();
        $this->_column_headers = [$this->get_columns(), [], $this->get_sortable_columns()];

// تعیین تعداد آیتم‌ها و صفحه فعلی

        $per_page = 3;
        $current_page = $this->get_pagenum();
        $offset = ($current_page - 1) * $per_page;
        $orderby = isset($_GET['orderby']) ? $_GET['orderby'] : false;
        $order = isset($_GET['order']) ? $_GET['order'] : false;
        $cluse_order = "";
        if ($orderby && $order) {
            $cluse_order = " ORDER BY $orderby $order";
        }

        global $wpdb;
        $table_name = $wpdb->prefix . "prousers";
        $query = $wpdb->prepare(
            "SELECT SQL_CALC_FOUND_ROWS * FROM `$table_name` $cluse_order LIMIT $per_page OFFSET $offset ",);
        $users = $wpdb->get_results($query, ARRAY_A);
        $this->set_pagination_args([
            'total_items' => $wpdb->get_var("SELECT FOUND_ROWS()"),
            'per_page' => $per_page
        ]);
        $this->items = $users;
    }
    
    /// process data for bulk actions
    public function proccess_data_in_bulk_actions()
    {
       if ($this->current_action() == 'delete') {
           $ids = $_POST['pro_user_select'];
           $records = count($ids);
           foreach ($ids as $id) {
               global $wpdb;
               $tbl_name = $wpdb->prefix . "prousers";
               $res_delete = $wpdb->delete($tbl_name, ['id' => $id]);
           }
           if ($res_delete) {
               echo "<div class='notice notice-success'>";
               echo "<p>تعداد $records رکورد حذف شد.</p>";
               echo "</div>";
           }
       }
    }


    private function create_view($key , $value , $url , $count = 0)
    {
        $view_tag = '';
        $view_tag = sprintf("<a href='%s'>%s</a>", $url, $count);
        return $view_tag;
    }

    protected function get_views()
    {
        $all = 25;
        $hav_vip = 3;
        return array(
            'all' => "<a class='current' href='#'>$all تمام کارمندان </a>",
            'hav_vip' => "<a href='#'>$hav_vip  دارای اشتراک </a>",
        );
    }
}
