<?php
// اضافه کردن منوی مدیریت کاربران VIP
function vip_users_admin_menu() {
    add_menu_page(
        'مدیریت کاربران VIP', // عنوان صفحه
        'کاربران VIP', // عنوان منو
        'manage_options', // قابلیت دسترسی
        'vip-users', // شناسه منو
        'vip_users_management_page', // تابع برای نمایش محتوا
        'dashicons-star-filled', // آیکون منو
        6 // موقعیت منو
    );
    // زیرمنوی نمایش کاربران VIP
    add_submenu_page(
        'vip-users', // شناسه منوی والد
        'لیست کاربران VIP', // عنوان صفحه
        'نمایش کاربران VIP', // عنوان زیرمنو
        'manage_options', // قابلیت دسترسی
        'vip-users-list', // شناسه زیرمنو
        'vip_users_list_page' // تابع برای نمایش محتوا
    );
}
add_action('admin_menu', 'vip_users_admin_menu');

// نمایش صفحه مدیریت کاربران VIP
function vip_users_management_page() {
    ?>
    <div class="wrap">
        <h1>مدیریت کاربران VIP</h1>
        <form method="post" action="">
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">نام کامل</th>
                    <td>
                        <input type="text" name="vip_user_full_name" placeholder="نام کامل" required />
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">تاریخ تولد</th>
                    <td>
                        <input type="date" name="vip_user_dob" required />
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">ایمیل</th>
                    <td>
                        <input type="email" name="vip_user_email" placeholder="ایمیل کاربر" required />
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">تصویر</th>
                    <td>
                        <input type="text" name="vip_user_img" placeholder="تصویر کاربر" required />
                    </td>
                </tr>
                <tr valign="top">
                    <td colspan="2">
                        <input type="submit" name="add_vip_user" class="button button-primary" value="افزودن" />
                    </td>
                </tr>
            </table>
        </form>
    </div>
    <?php
}
add_action('admin_init', 'form_submit');
function form_submit() {
    global $pagenow;
    if ($pagenow == 'admin.php' && isset($_GET['page']) && $_GET['page'] == 'vip-users') {
       if (isset($_POST['add_vip_user'])) {
           $full_name = $_POST['vip_user_full_name'];
           $email = $_POST['vip_user_email'];
           $img = $_POST['vip_user_img'];
           $birthday = $_POST['vip_user_dob'];
           global $wpdb;
           $data = [
               'full_name' => $full_name,
               'email' => $email,
               'birthday' => $birthday,
               'img' => $img
           ];
           $inserted = $wpdb->insert($wpdb->prefix."prousers" , $data  , ['%s', '%s', '%s' , '%s']);
           if ($inserted) {
               $user_id = $wpdb->insert_id;
               wp_safe_redirect(admin_url() . "admin.php?page=vip-users&status=success&user_inserted=$user_id");
           }
       }
    }
}
add_action('admin_notices', 'zlm_notices');
function zlm_notices() {
    if ( $_GET['page'] == "vip-users"  && isset($_GET['status']) && $_GET['status'] == 'success') {
        echo '<div class="notice notice-success is-dismissible">';
            echo "<p>کاربر با موفقت اضافه شد!</p>";
        echo '</div>';
    }
}

// تابع نمایش لیست کاربران VIP در زیرمنو
function vip_users_list_page() {
    if (isset($_GET['action']) && $_GET['action'] == 'delete') {
        $id = $_GET['id'];
        global $wpdb;
        $tbl = $wpdb->prefix . "prousers";
        $wpdb->delete($tbl, ['id' => $id]);
    }

    echo '<div class="wrap">';
    echo '<h1 class="wp-heading-inline"> Pro Users
<a target="_blank" href="' . admin_url("?page=vip-users") . '" class="page-title-action">Add New Pro User</a>
</h1>';
    include PRO_USER_DIR . "includes/WP_LIST_TABLE_EMP.php";
    $obj = new VIP_Users_List_Table();
    $obj->prepare_items();
    $obj->views();
    echo "<form method='post'>";
    $obj->display();
    echo "</form>";
    echo '</div>';
    return;
    ?>





    <div class="wrap">
        <h1>لیست کاربران VIP</h1>
        <?php
        // واکشی لیست کاربران VIP

        ## for several rows
        global $wpdb;
        $table_name = $wpdb->prefix . 'prousers'; // نام جدول

        // کوئری برای واکشی چندین ردیف
        $results = $wpdb->get_results( "SELECT * FROM $table_name", OBJECT );

        if (!empty($results)) {
            echo '<table class="widefat fixed striped">';
            echo '<thead><tr><th>نام کامل</th><th>تاریخ تولد</th><th>ایمیل</th></tr></thead>';
            echo '<tbody>';
            foreach ($results as $vip_user) {
                $full_name = $vip_user->full_name;
                $email = $vip_user->email;
                $birthday = $vip_user->birthday;
                echo '<tr>';
                echo '<td>' . esc_html($full_name) . '</td>';
                echo '<td>' . esc_html($birthday) . '</td>';
                echo '<td>' . esc_html($email) . '</td>';
                echo '</tr>';
            }
            echo '</tbody>';
            echo '</table>';
        } else {
            echo '<p>هنوز هیچ کاربر VIPی ثبت نشده است.</p>';
        }
        ?>
    </div>
    <?php
}