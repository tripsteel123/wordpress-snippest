<?php
/*
 * Plugin Name: pro_users
 */

register_activation_hook(__FILE__, 'management_users_activate');
function management_users_activate()
{
    global $wpdb;
    ## get code by SHOW CREATE TABLE wp_prousers
    $tbl_name = $wpdb->prefix . "prousers";
    $sql = "
    CREATE TABLE `$tbl_name` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(255) NOT NULL,
  `birthday` date NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`ID`)
    ) 
        ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    ";
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta( $sql );
}

## delete table in deactive plugin
register_deactivation_hook(__FILE__, 'management_users_deactivate');
function management_users_deactivate() {
    global $wpdb;
    $tbl_name = $wpdb->prefix . "prousers";
    $wpdb->query("DROP TABLE IF EXISTS $tbl_name");
}

define("PRO_USER_DIR" , plugin_dir_path( __FILE__ ));
include PRO_USER_DIR."includes/menues.php";

